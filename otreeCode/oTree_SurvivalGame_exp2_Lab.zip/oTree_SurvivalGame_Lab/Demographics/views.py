from otree.api import Currency as c, currency_range
from . import models
from ._builtin import Page, WaitPage
from .models import Constants


class ConsentForm(Page):
    pass


class Demographics(Page):
    form_model = models.Player
    form_fields = ['age', 'sex', 'language']


page_sequence = [
    ConsentForm,
    Demographics
]
