from otree.api import Currency as c, currency_range
from . import models
from ._builtin import Page, WaitPage
from .models import Constants
import random

class ResetWait(WaitPage):
    def after_all_players_arrive(self):
        for p in self.group.get_players():
            p.participant.vars['go_to_the_end'] = False
            # initially go_to_the_end = False, but will be set to True if participant abandons game

            p.participant.vars['waiting_time_lobby'] = 0
            # time spent waiting in the lobby goes here

            p.participant.vars['payment_for_wait'] = 0
            # payment_for_wait is amount paid for waiting in the lobby

            p.participant.vars['payment_for_game'] = 0
            # payment from the game itself goes here

            p.participant.vars['herd_size'] = c(self.session.config['initialherd'])
            # herd_size variable holds the participant's current herd size

            p.participant.vars['total_cattle_lost'] = 0
            # count of number of cattle lost to disasters (shocks) across all years

            p.participant.vars['under_minimum_years_left'] = self.session.config['years_before_death']
            # under_minimum_years_left decreases every year the player is under the minimum threshold

            p.participant.vars['dead'] = False
            # this is set to True when a player dies, and they are removed from the game

            p.participant.vars['debt'] = []
            # this variable is used to calculate repetitive giving and asking

            p.participant.vars['repetitive_giving'] = 0
            # this counter goes up every time the player gives to another player without being reciprocated

            p.participant.vars['repetitive_asking'] = 0
            # this count goes up every time the player asks for cattle from a player they have yet to reciprocate to

            p.participant.vars['others_in_network'] = []
            # a list of all the players in the participant's 'network'
            # (more relevant when nonrandom_network_limited_degree = True)

            p.participant.vars['shock_predictable_yearcount'] = random.randint(
                1, self.session.config['shock_predictable_years'])
            # when shocks occur every x years, this sets the initial 'year count cycle' at 1 <= yearcount <= x
            # then when yearcount = x, a shock occurs


class Manipulation(Page):
    def vars_for_template(self):
        if self.session.config['counterbalancing'] == 1:
            observability = False
        elif self.session.config['counterbalancing'] == 2:
            observability = True
        return {'observability': observability}


page_sequence = [
    ResetWait,
    Manipulation,
]
