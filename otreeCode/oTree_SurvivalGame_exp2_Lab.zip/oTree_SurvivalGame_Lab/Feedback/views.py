from otree.api import Currency as c, currency_range
from . import models
from ._builtin import Page, WaitPage
from .models import Constants
import random


class ExitSurvey(Page):
    form_model = models.Player
    form_fields = [
                   #  'feel_bad_need',
                   'feel_bad_ask',
                   'fairness',
                   'risk_pooling_true',
                   'risk_pooling_false',
                   'why_give']


class EmpathyScale(Page):
    form_model = models.Player
    form_fields = ['empathy{}'.format(i) for i in range(1,17)]

    def get_form_fields(self):
        fields = self.form_fields
        random.shuffle(fields)
        return fields

    def before_next_page(self):
        self.player.calculate_empathy_composite()


class Feedback(Page):
    form_model = models.Player
    form_fields = ['rushed',
                   'waiting',
                   'instructions',
                   'feedback']


class DebriefForm(Page):
    pass


page_sequence = [
    ExitSurvey,
    EmpathyScale,
    Feedback,
    DebriefForm
]
