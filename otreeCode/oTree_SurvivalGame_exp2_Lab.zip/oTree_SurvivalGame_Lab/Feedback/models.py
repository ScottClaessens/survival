from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)


author = 'Scott Claessens'

doc = """
Feedback
"""


class Constants(BaseConstants):
    name_in_url = 'Feedback'
    players_per_group = None
    num_rounds = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    #
    # Empathy questions (how they played the game)
    #
    #

    feel_bad_ask = models.PositiveIntegerField(
        verbose_name="I felt bad for my partner when they asked me for cattle.",
        choices=[
            [5, "Strongly agree"],
            [4, "Agree"],
            [3, "Neither agree nor disagree"],
            [2, "Disagree"],
            [1, "Strongly disagree"]
        ],
        widget=widgets.RadioSelect,
    )

    fairness = models.PositiveIntegerField(
        verbose_name="I felt that it was fair to give cattle to my partner when asked me for cattle.",
        choices=[
            [5, "Strongly agree"],
            [4, "Agree"],
            [3, "Neither agree nor disagree"],
            [2, "Disagree"],
            [1, "Strongly disagree"]
        ],
        widget=widgets.RadioSelect,
    )

    risk_pooling_true = models.PositiveIntegerField(
        verbose_name="One way to survive for more years was to give "
                     "cattle to my partner when they asked.",
        choices=[
            [5, "Strongly agree"],
            [4, "Agree"],
            [3, "Neither agree nor disagree"],
            [2, "Disagree"],
            [1, "Strongly disagree"]
        ],
        widget=widgets.RadioSelect,
    )

    risk_pooling_false = models.PositiveIntegerField(
        verbose_name="One way to survive for more years was to keep "
                     "all the cattle to myself.",
        choices=[
            [5, "Strongly agree"],
            [4, "Agree"],
            [3, "Neither agree nor disagree"],
            [2, "Disagree"],
            [1, "Strongly disagree"]
        ],
        widget=widgets.RadioSelect,
    )

    why_give = models.TextField(
        blank=True
    )

    #
    # Empathy questions (how they played the game)
    #
    #

    empathy1 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="When someone else is feeling excited, I tend to get excited too")
    empathy2 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="Other people's misfortunes do not disturb me a great deal")
    empathy3 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="It upsets me to see someone being treated disrespectfully")
    empathy4 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="I remain unaffected when someone close to me is happy")
    empathy5 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="I enjoy making other people feel better")
    empathy6 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="I have tender, concerned feelings for people less fortunate than me")
    empathy7 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="When a friend starts to talk about their problems, I try to steer the conversation towards something else")
    empathy8 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="I can tell when others are sad even when they do not say anything")
    empathy9 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="I find that I am 'in tune' with other people's moods")
    empathy10 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="I do not feel sympathy for people who cause their own serious illnesses")
    empathy11 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="I become irritated when someone cries")
    empathy12 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="I am not really interested in how other people feel")
    empathy13 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="I get a strong urge to help when I see someone who is upset")
    empathy14 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="When I see someone being treated unfairly, I do not feel pity very much for them")
    empathy15 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="I find it silly for people to cry out of happiness")
    empathy16 = models.PositiveIntegerField(
        choices=[0, 1, 2, 3, 4],
        verbose_name="When I see someone being taken advantage of, I feel kind of protective towards them")

    def calculate_empathy_composite(self):
        self.empathy_composite = self.empathy1 + \
                                 (4 - self.empathy2) + \
                                 self.empathy3 + \
                                 (4 - self.empathy4) + \
                                 self.empathy5 + \
                                 self.empathy6 + \
                                 (4 - self.empathy7) + \
                                 self.empathy8 + \
                                 self.empathy9 + \
                                 (4 - self.empathy10) + \
                                 (4 - self.empathy11) + \
                                 (4 - self.empathy12) + \
                                 self.empathy13 + \
                                 (4 - self.empathy14) + \
                                 (4 - self.empathy15) + \
                                 self.empathy16

    empathy_composite = models.PositiveIntegerField()

    #
    # Feedback questions (blank=True means participants do not have to answer)
    #
    rushed = models.PositiveIntegerField(
        verbose_name="I felt under time pressure to make decisions during the game.",
        choices=[
            [5, "Strongly agree"],
            [4, "Agree"],
            [3, "Neither agree nor disagree"],
            [2, "Disagree"],
            [1, "Strongly disagree"]
        ],
        widget=widgets.RadioSelect,
    )

    waiting = models.PositiveIntegerField(
        verbose_name="I felt that I was waiting a long time for the other player.",
        choices=[
            [5, "Strongly agree"],
            [4, "Agree"],
            [3, "Neither agree nor disagree"],
            [2, "Disagree"],
            [1, "Strongly disagree"]
        ],
        widget=widgets.RadioSelect,
    )

    instructions = models.PositiveIntegerField(
        verbose_name="The instructions for the game were easy to understand.",
        choices=[
            [5, "Strongly agree"],
            [4, "Agree"],
            [3, "Neither agree nor disagree"],
            [2, "Disagree"],
            [1, "Strongly disagree"]
        ],
        widget=widgets.RadioSelect,
    )

    feedback = models.TextField(
        blank=True
    )



